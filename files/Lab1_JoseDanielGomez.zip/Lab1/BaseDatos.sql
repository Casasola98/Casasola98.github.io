CREATE DATABASE login;

USE login;
CREATE TABLE usuarios (nombre VARCHAR(30), apellido VARCHAR(30), username VARCHAR(30), correo VARCHAR(40), contrasena VARCHAR(20), celular VARCHAR(8), fecha DATE, PRIMARY KEY (username));

DELIMITER $$
CREATE PROCEDURE obtenerUsuario(correoS VARCHAR(40), contrasenaS VARCHAR(20))
BEGIN
SELECT * FROM usuarios WHERE correo=correoS AND contrasena=contrasenaS;
END $$

CREATE PROCEDURE obtenerUsu(correoS VARCHAR(40))
BEGIN
SELECT * FROM usuarios WHERE correo=correoS;
END $$

CREATE PROCEDURE obtenerUsername(user VARCHAR(40))
BEGIN
SELECT * FROM usuarios WHERE username=user;
END $$

CREATE PROCEDURE cambiarContrasena(correoS VARCHAR(40), contrasenaS VARCHAR(20))
BEGIN
UPDATE usuarios SET contrasena=contrasenaS WHERE correo=correoS;
END $$

CREATE PROCEDURE registrarUsu(nomb VARCHAR(30), apell VARCHAR(30), user VARCHAR(30), corr VARCHAR(40), contras VARCHAR(20), cel VARCHAR(8), fech VARCHAR(12))
BEGIN
INSERT INTO usuarios (nombre, apellido, username, correo, contrasena, celular, fecha) VALUES (nomb, apell, user, corr, contras, cel, fech);
END $$

DELIMITER ;
