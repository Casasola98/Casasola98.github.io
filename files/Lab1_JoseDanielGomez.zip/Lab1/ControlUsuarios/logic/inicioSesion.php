<?php 
    include 'ControllerUsuarios.php';
    $correo = $_POST['correo'];
    $passwd = $_POST['passwd'];
    
    $controlador = new ControllerUsuarios;
    $controlador->login($correo, $passwd);
?>