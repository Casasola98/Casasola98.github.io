<?php

include 'DAOUsuarios.php';

class ValidacionUsuarios {
    public $daoUsu;

    function __construct() {
        $this->daoUsu = new DAOUsuarios;
    }

    function validarPasswd($passwd){
        if(strlen($passwd) < 8){
           return false;
        }
        if (!preg_match('`[a-z]`',$passwd)){
           return false;
        }
        if (!preg_match('`[A-Z]`',$passwd)){
           return false;
        }
        if (!preg_match('`[0-9]`',$passwd)){
           return false;
        }
        return true;
    }

    function login($correo, $passwd) {
        if(strlen($correo) > 0 && strlen($passwd) > 0) {
            if($this->validarPasswd($passwd)) {
                $this->daoUsu->conectar();
                $array = $this->daoUsu->obtenerUsuario($correo, $passwd);
                $this->daoUsu->desconectar();
                //echo $array['correo'];
                if(count($array) == 0) {
                    echo '<script type="text/JavaScript">  
                    alert("Los datos suministrados no corresponden a ningún usuario");
                    window.location.href = history.back();
                    </script>'; 
                } else { 
                    echo '<script type="text/JavaScript">  
                    window.location.href = "../portal.php?'. $array['username'] .'";
                    </script>';
                }
            } else {
                echo '<script type="text/JavaScript">  
                    alert("La contraseña debe poseer como mínimo 8 caracteres, mayúsculas, minúsculas y números");
                    window.location.href = history.back();
                    </script>'; 
            }
        } else {
            echo '<script type="text/JavaScript">  
                alert("Debe escribir el correo y la contraseña del usuario a ingresar");
                window.location.href = history.back();
                </script>';
        }
    }

    function cambioPasswd($correo, $passwd, $newPasswd, $newPasswd2) {
        if(strlen($correo) > 0 && strlen($passwd) > 0 && strlen($newPasswd) > 0 && strlen($newPasswd2) > 0) {
            if($newPasswd == $newPasswd2){
                if($this->validarPasswd($passwd) & $this->validarPasswd($newPasswd)) {
                    $this->daoUsu->conectar();
                    $array = $this->daoUsu->obtenerUsuario($correo, $passwd);
                    $this->daoUsu->desconectar();
                    //echo $array['correo'];
                    if(count($array) == 0) {
                        echo '<script type="text/JavaScript">  
                        alert("Los datos suministrados no corresponden a ningún usuario");
                        window.location.href = history.back();
                        </script>'; 
                    } else { 
                        $this->daoUsu->conectar();
                        $this->daoUsu->cambiarContrasena($correo, $newPasswd);
                        $this->daoUsu->desconectar();
                        echo '<script type="text/JavaScript">  
                        alert("La contraseña ha sido cambiada");
                        window.location.href = "../index.php";
                        </script>';
                    }
                } else {
                    echo '<script type="text/JavaScript">  
                        alert("La contraseña debe poseer como mínimo 8 caracteres, mayúsculas, minúsculas y números");
                        window.location.href = history.back();
                        </script>'; 
                }
            } else {
                echo '<script type="text/JavaScript">  
                    alert("La nueva contraseña debe ser igual a la confirmación");
                    window.location.href = history.back();
                    </script>'; 
            }
        } else {
            echo '<script type="text/JavaScript">  
                alert("Debe escribir el correo y la contraseña del usuario a ingresar");
                window.location.href = history.back();
                </script>';
        }
    }

    function olvidaPasswd($correo) {
        if(strlen($correo) > 0) {
            $this->daoUsu->conectar();
            $array = $this->daoUsu->obtenerUsu($correo);
            $this->daoUsu->desconectar();
            //echo $array['correo'];
            if(count($array) == 0) {
                echo '<script type="text/JavaScript">  
                alert("El correo suministrado no corresponde a ningún usuario");
                window.location.href = history.back();
                </script>'; 
            } else { 
                $this->daoUsu->conectar();
                $this->daoUsu->cambiarContrasena($correo, "ABcd1234");
                $this->daoUsu->desconectar();
                echo '<script type="text/JavaScript">  
                alert("Nueva contraseña: ABcd1234 \r\n Un correo con su nueva contraseña ha sido enviado a su dirección de correo electrónico");
                window.location.href = "../index.php";
                </script>';
            }
            
        } else {
            echo '<script type="text/JavaScript">  
                alert("Debe escribir el correo del usuario");
                window.location.href = history.back();
                </script>';
        }
    }

    function signup($nombre, $apellido, $username, $correo, $passwd, $celular, $fecha) {
        if(strlen($correo) > 0) {
            $this->daoUsu->conectar();
            $array = $this->daoUsu->obtenerUsu($correo);
            $this->daoUsu->desconectar();
            $this->daoUsu->conectar();
            $array2 = $this->daoUsu->obtenerUsername($username);
            $this->daoUsu->desconectar();
            if(count($array) != 0) {
                echo '<script type="text/JavaScript">  
                alert("Ya existe un usuario con dicho correo");
                window.location.href = history.back();
                </script>'; 
            } else { 
                if(count($array2) != 0) {
                    echo '<script type="text/JavaScript">  
                    alert("Ya existe un usuario con dicho username");
                    window.location.href = history.back();
                    </script>'; 
                } else { 
                    if ($this->validarPasswd($passwd)) {
                        $this->daoUsu->conectar();
                        $this->daoUsu->registrarUsu($nombre, $apellido, $username, $correo, $passwd, $celular, $fecha);
                        $this->daoUsu->desconectar();
                        echo '<script type="text/JavaScript">  
                        alert("Usuario registrado!");
                        window.location.href = "../index.php";
                        </script>';
                    } else {
                        echo '<script type="text/JavaScript">  
                            alert("La contraseña debe poseer como mínimo 8 caracteres, mayúsculas, minúsculas y números");
                            window.location.href = history.back();
                            </script>';
                    }
                }
            }
        } else {
            echo '<script type="text/JavaScript">  
                alert("Debe escribir el correo del usuario");
                window.location.href = history.back();
                </script>';
        }
    }
}

?>