<?php

include 'ValidacionUsuarios.php';

class ControllerUsuarios {
    public $validacion;

    function __construct() {
        $this->validacion = new ValidacionUsuarios;
    }

    function login($correo, $passwd) {
        $this->validacion->login($correo, $passwd);
    }

    function cambioPasswd($correo, $passwd, $newPasswd, $newPasswd2) {
        $this->validacion->cambioPasswd($correo, $passwd, $newPasswd, $newPasswd2);
    }

    function olvidaPasswd($correo) {
        $this->validacion->olvidaPasswd($correo);
    }

    function signup($nombre, $apellido, $username, $correo, $passwd, $celular, $fecha) {
        $this->validacion->signup($nombre, $apellido, $username, $correo, $passwd, $celular, $fecha);
    }
}

?>