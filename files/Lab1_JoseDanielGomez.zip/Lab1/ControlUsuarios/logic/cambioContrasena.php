<?php 
    include 'ControllerUsuarios.php';
    $correo = $_POST['correo'];
    $passwd = $_POST['passwd']; 
    $newPasswd = $_POST['newPasswd'];
    $newPasswd2 = $_POST['newPasswd2'];
    
    $controlador = new ControllerUsuarios;
    $controlador->cambioPasswd($correo, $passwd, $newPasswd, $newPasswd2);
?>