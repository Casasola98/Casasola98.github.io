<?php

class DAOUsuarios {
    public $servidor = "localhost";
    public $datab = "login";
    public $user = "root";
    public $pass = "";
    public $conn;

    function conectar() {
        $this->conn = mysqli_connect( $this->servidor, $this->user, $this->pass, $this->datab) or die ("No se ha podido conectar al servidor de base de datos");
    }

    function desconectar() {
        mysqli_close($this->conn);
    }

    function obtenerUsuario($correo, $passwd){
        $db = mysqli_select_db( $this->conn, $this->datab ) or die ( "No se ha podido conectar a la base de datos" );
        
        $consulta = "CALL obtenerUsuario('{$correo}', '{$passwd}');";
        $resultado = mysqli_query( $this->conn, $consulta ) or die ( "Error al realizar la consulta");
        
        $columna = array();
        if (mysqli_num_rows($resultado)>0) {
            $columna = mysqli_fetch_array($resultado);
        }
        return $columna;
    }

    function obtenerUsu($correo){
        $db = mysqli_select_db( $this->conn, $this->datab ) or die ( "No se ha podido conectar a la base de datos" );
        
        $consulta = "CALL obtenerUsu('{$correo}');";
        $resultado = mysqli_query( $this->conn, $consulta ) or die ( "Error al realizar la consulta");

        $columna = array();
        if (mysqli_num_rows($resultado)>0) {
            $columna = mysqli_fetch_array($resultado);
        }
        return $columna;
    }

    function obtenerUsername($username){
        $db = mysqli_select_db( $this->conn, $this->datab ) or die ( "No se ha podido conectar a la base de datos" );
        
        $consulta = "CALL obtenerUsername('{$username}');";
        $resultado = mysqli_query( $this->conn, $consulta ) or die ( "Error al realizar la consulta");

        $columna = array();
        if (mysqli_num_rows($resultado)>0) {
            $columna = mysqli_fetch_array($resultado);
        }
        return $columna;
    }

    function cambiarContrasena($correo, $passwd) {
        $consulta = "CALL cambiarContrasena('{$correo}', '{$passwd}');"; 
        if(mysqli_query($this->conn, $consulta)){ 
            return true; 
        } else { 
            return false; 
        }
    }

    function registrarUsu($nombre, $apellido, $username, $correo, $passwd, $celular, $fecha) {
        $consulta = "CALL registrarUsu('{$nombre}', '{$apellido}', '{$username}', '{$correo}', '{$passwd}', '{$celular}', '{$fecha}');"; 
        if(mysqli_query($this->conn, $consulta)){ 
            return true; 
        } else { 
            return false; 
        }
    }
}

?>