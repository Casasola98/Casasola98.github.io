<?php 
    include 'ControllerUsuarios.php';
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $username = $_POST['username'];
    $correo = $_POST['correo'];
    $passwd = $_POST['passwd']; 
    $celular = $_POST['celular'];
    $fecha = $_POST['fecha'];
    
    $controlador = new ControllerUsuarios;
    $controlador->signup($nombre, $apellido, $username, $correo, $passwd, $celular, $fecha);
?>