<?php 
    include 'ControllerUsuarios.php';
    $correo = $_POST['correo'];
    
    $controlador = new ControllerUsuarios;
    $controlador->olvidaPasswd($correo);
?>